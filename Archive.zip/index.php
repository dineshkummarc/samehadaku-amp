<?php include 'vars.php'; ?>
<!DOCTYPE html>
<html amp lang="id">
<?php include 'header.php'; ?>
<body>
<?php include 'header-mobile.php'; ?>
<?php include 'sidebar.php'; ?>
<?php include 'homepage.php'; ?>
<?php include 'footer.php'; ?>
</body>
</html>